<?php
  require('cabecera.php');
 ?>
<html>
<body>
      <nav class="navbar navbar-default">
        <div class="container">
             <ul class="nav navbar-nav navbar-right">
               <li><a href="./capUsuario.php"><span class="glyphicon glyphicon-user"></span> Registro</a></li>
               <li><a href="./login.php"><span class="glyphicon glyphicon-log-in"></span> Entrar</a></li>
             </ul>
       </div>
      </nav>

      <div class="container" style="margin: auto; background-color:#fff; padding:auto;">
          <div class="jumbotron">
             <h1>DataBase & Deploy Apps</h1>
             <p>Gerencia de Tecnologías | Coordinación de Desarrollo</p>
         </div>
      </div>
      <hr>

</body>
<footer style="text-align:center;">© Tienda de Descuento Arteli - <?php echo date("Y");?></footer>
</html>
